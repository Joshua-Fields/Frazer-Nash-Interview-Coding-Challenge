﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LicenseContext = OfficeOpenXml.LicenseContext;

namespace Coding_Challenge
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Ingredients

            //bread slice
            double b = (1.20 / 24);
            //Bacon Rasher
            double B = (2.40 / 8);
            //Lettuce Leaf
            double L = (.50 / 20);
            //Tomato Slice
            double T = (.24 / 4);
            //Chicken Chunk
            double c = (2.45 / 10);
            //Sweetcorn Portion
            double S = (.50 / 20);
            //Cheese Slice
            double C = (20 / 2.50);
            //Ham Slice
            double H = (1.20 / 24);
            //Coronation Chicken Portion
            double k = (2.00 / 10);
            //Egg
            double E = (1.20 / 12);
            //Cress
            double s = (1.60 / 32);

            //Overhead and labour

            //Overhead
            double overhead = .20;
            //Labour
            double lL = .20;
            double lH = .40;



            //Sandwiches

            double BLT = b + B + L + T + b+ lL;
            double chickenSweetcorn = b + c + S + b + lL;
            double cheeseTomato = b + C + T + b + lL;
            double cheeseHam = b + c + H + b + lL;
            double coronationChicken = b + k + b + lL;
            double englishBreakfast = b + E + s + b + lL;
            double eggCress = b + E + s + b + lL;


            //SellingPrice
            double BLTS = (BLT + BLT * .50);
            double chickenSweetcornS = (chickenSweetcorn + chickenSweetcorn * .50);
            double cheeseTomatoS = (cheeseTomato + cheeseTomato * .50);
            double cheeseHamS = (cheeseHam + cheeseHam * .50);
            double coronationChickenS = (coronationChicken + coronationChicken * .50);
            double englishBreakfastS = (englishBreakfast + englishBreakfast * .50);
            double eggCressS = (eggCress + eggCress * .50);



            //Rounded Selling Price
            double RBLTS = Math.Round(BLTS);
            double RchickenSweetcornS = Math.Round(chickenSweetcornS);
            double RcheeseTomatoS = Math.Round(cheeseTomatoS);
            double RcheeseHamS = Math.Round(cheeseHamS);
            double RcoronationChickenS = Math.Round(coronationChickenS);
            double RenglishBreakfastS = Math.Round(englishBreakfastS);
            double ReggCressS = Math.Round(eggCressS);






            //Profit
            double BLTP = BLTS - BLT;
            double chickenSweetcornP = chickenSweetcornS - chickenSweetcorn;
            double cheeseTomatoP = cheeseTomatoS - cheeseTomato;
            double cheeseHamP = cheeseHamS - cheeseHam;
            double coronationChickenP = coronationChickenS - coronationChicken;
            double englishBreakfastP = englishBreakfastS - englishBreakfast;
            double eggCressP = eggCressS - eggCress;











            var activities = new List<Activity>()
            {
                new Activity(){ Name="BLT", totalCost=BLT, sellingPrice=RBLTS, profit=BLTP},
                new Activity(){Name="Chicken & Sweetcorn", totalCost=chickenSweetcorn, sellingPrice=RchickenSweetcornS, profit=chickenSweetcornP},
                new Activity(){Name="Cheese & Tomato", totalCost=cheeseTomato, sellingPrice=cheeseTomatoS, profit=cheeseTomatoP},
                new Activity(){Name="Cheese & Ham", totalCost=cheeseHam, sellingPrice=RcheeseHamS, profit=cheeseHamP},
                new Activity(){Name="Coronation Chicken", totalCost=coronationChicken, sellingPrice=RcoronationChickenS, profit=coronationChickenP},
                new Activity(){Name="English Breakfast", totalCost=englishBreakfast, sellingPrice=RenglishBreakfastS, profit=englishBreakfastP},
                new Activity(){Name="Egg & Cress", totalCost=eggCress, sellingPrice=ReggCressS, profit=eggCressP},

            };
            CreateSpreadsheet(activities);
            MessageBox.Show("Spreadsheet has been created");
        }

        private void CreateSpreadsheet(List<Activity> activities)
        {
            string spreadsheetPath = "Task_1.xlsx";
            File.Delete(spreadsheetPath);
            FileInfo spreadsheetInfo = new FileInfo(spreadsheetPath);
            ExcelPackage.LicenseContext = LicenseContext.Commercial;

            ExcelPackage pck = new ExcelPackage(spreadsheetInfo);
            var activitiesWorksheet = pck.Workbook.Worksheets.Add("Activities");
            activitiesWorksheet.Cells["A1"].Value = "Sandwich";
            activitiesWorksheet.Cells["B1"].Value = "Total Cost";
            activitiesWorksheet.Cells["C1"].Value = "Selling Price";
            activitiesWorksheet.Cells["D1"].Value = "Profit";
            activitiesWorksheet.Cells["A1:D1"].Style.Font.Bold = true;

            // Populate spreadsheet with data
            int currentRow = 2;
            foreach (var activity in activities)
            {
                activitiesWorksheet.Cells["A" + currentRow.ToString()].Value = activity.Name;
                activitiesWorksheet.Cells["B" + currentRow.ToString()].Value = activity.totalCost;
                activitiesWorksheet.Cells["C" + currentRow.ToString()].Value = activity.sellingPrice;
                activitiesWorksheet.Cells["D" + currentRow.ToString()].Value = activity.profit;

                currentRow++;
            }

            activitiesWorksheet.View.FreezePanes(2, 1);

            pck.Save();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Ingredients

            //bread slice
            double b = (1.20 / 24);
            //Bacon Rasher
            double B = (2.40 / 8);
            //Lettuce Leaf
            double L = (.50 / 20);
            //Tomato Slice
            double T = (.24 / 4);
            //Chicken Chunk
            double c = (2.45 / 10);
            //Sweetcorn Portion
            double S = (.50 / 20);
            //Cheese Slice
            double C = (20 / 2.50);
            //Ham Slice
            double H = (1.20 / 24);
            //Coronation Chicken Portion
            double k = (2.00 / 10);
            //Egg
            double E = (1.20 / 12);
            //Cress
            double s = (1.60 / 32);

            //Overhead and labour

            //Overhead
            double overhead = .20;
            //Labour
            double lL = .20;
            double lH = .40;



            //Sandwiches

            double BLT = b + B + L + T + b + lL;
            double chickenSweetcorn = b + c + S + b + lL;
            double cheeseTomato = b + C + T + b + lL;
            double cheeseHam = b + c + H + b + lL;
            double coronationChicken = b + k + b + lL;
            double englishBreakfast = b + E + s + b + lL;
            double eggCress = b + E + s + b + lL;


            //SellingPrice
            double BLTS = (BLT + BLT * .50);
            double chickenSweetcornS = (chickenSweetcorn + chickenSweetcorn * .50);
            double cheeseTomatoS = (cheeseTomato + cheeseTomato * .50);
            double cheeseHamS = (cheeseHam + cheeseHam * .50);
            double coronationChickenS = (coronationChicken + coronationChicken * .50);
            double englishBreakfastS = (englishBreakfast + englishBreakfast * .50);
            double eggCressS = (eggCress + eggCress * .50);



            //Rounded Selling Price
            double RBLTS = Math.Round(BLTS);
            double RchickenSweetcornS = Math.Round(chickenSweetcornS);
            double RcheeseTomatoS = Math.Round(cheeseTomatoS);
            double RcheeseHamS = Math.Round(cheeseHamS);
            double RcoronationChickenS = Math.Round(coronationChickenS);
            double RenglishBreakfastS = Math.Round(englishBreakfastS);
            double ReggCressS = Math.Round(eggCressS);






            //Profit
            double BLTP = BLTS - BLT;
            double chickenSweetcornP = chickenSweetcornS - chickenSweetcorn;
            double cheeseTomatoP = cheeseTomatoS - cheeseTomato;
            double cheeseHamP = cheeseHamS - cheeseHam;
            double coronationChickenP = coronationChickenS - coronationChicken;
            double englishBreakfastP = englishBreakfastS - englishBreakfast;
            double eggCressP = eggCressS - eggCress;











            var activities = new List<Activity>()
            {
                new Activity(){ date="2021/05/01", numberOfSales=BLT, revenue=RBLTS, profit1=BLTP},
                new Activity(){date="2021/05/02", numberOfSales=chickenSweetcorn, revenue=RchickenSweetcornS, profit1=chickenSweetcornP},
                new Activity(){date="2021/05/03", numberOfSales=cheeseTomato, revenue=cheeseTomatoS, profit1=cheeseTomatoP},
                new Activity(){date="2021/05/04", numberOfSales=cheeseHam, revenue=RcheeseHamS, profit1=cheeseHamP},
                new Activity(){date="2021/05/05", numberOfSales=coronationChicken, revenue=RcoronationChickenS, profit1=coronationChickenP},
                new Activity(){date="2021/05/06", numberOfSales=englishBreakfast, revenue=RenglishBreakfastS, profit1=englishBreakfastP},
                new Activity(){date="2021/05/07", numberOfSales=eggCress, revenue=ReggCressS, profit1=eggCressP},
                new Activity(){date="2021/05/08", numberOfSales=eggCress, revenue=ReggCressS, profit1=eggCressP},
                new Activity(){date="2021/05/09", numberOfSales=eggCress, revenue=ReggCressS, profit1=eggCressP},
                new Activity(){date="2021/05/10", numberOfSales=eggCress, revenue=ReggCressS, profit1=eggCressP},


            };
            CreateSpreadsheet1(activities);
            MessageBox.Show("Spreadsheet has been created");
        }

        private void CreateSpreadsheet1(List<Activity> activities)
        {
            string spreadsheetPath = "Task_2.xlsx";
            File.Delete(spreadsheetPath);
            FileInfo spreadsheetInfo = new FileInfo(spreadsheetPath);
            ExcelPackage.LicenseContext = LicenseContext.Commercial;

            ExcelPackage pck = new ExcelPackage(spreadsheetInfo);
            var activitiesWorksheet = pck.Workbook.Worksheets.Add("Activities");
            activitiesWorksheet.Cells["A1"].Value = "Date";
            activitiesWorksheet.Cells["B1"].Value = "Number of Sales";
            activitiesWorksheet.Cells["C1"].Value = "Revenue";
            activitiesWorksheet.Cells["D1"].Value = "Profit";
            activitiesWorksheet.Cells["A1:D1"].Style.Font.Bold = true;

            // Populate spreadsheet with data
            int currentRow = 2;
            foreach (var activity in activities)
            {
                activitiesWorksheet.Cells["A" + currentRow.ToString()].Value = activity.date;
                activitiesWorksheet.Cells["B" + currentRow.ToString()].Value = activity.numberOfSales;
                activitiesWorksheet.Cells["C" + currentRow.ToString()].Value = activity.revenue;
                activitiesWorksheet.Cells["D" + currentRow.ToString()].Value = activity.profit1;

                currentRow++;
            }

            activitiesWorksheet.View.FreezePanes(2, 1);
            pck.Save();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                //Ingredients

                //bread slice
                double b = (1.20 / 24);
                //Bacon Rasher
                double B = (2.40 / 8);
                //Lettuce Leaf
                double L = (.50 / 20);
                //Tomato Slice
                double T = (.24 / 4);
                //Chicken Chunk
                double c = (2.45 / 10);
                //Sweetcorn Portion
                double S = (.50 / 20);
                //Cheese Slice
                double C = (20 / 2.50);
                //Ham Slice
                double H = (1.20 / 24);
                //Coronation Chicken Portion
                double k = (2.00 / 10);
                //Egg
                double E = (1.20 / 12);
                //Cress
                double s = (1.60 / 32);

                //Overhead and labour

                //Overhead
                double overhead = .20;
                //Labour
                double lL = .20;
                double lH = .40;



                //Sandwiches

                double BLT = b + B + L + T + b + lL;
                double chickenSweetcorn = b + c + S + b + lL;
                double cheeseTomato = b + C + T + b + lL;
                double cheeseHam = b + c + H + b + lL;
                double coronationChicken = b + k + b + lL;
                double englishBreakfast = b + E + s + b + lL;
                double eggCress = b + E + s + b + lL;


                //SellingPrice
                double BLTS = (BLT + BLT * .50);
                double chickenSweetcornS = (chickenSweetcorn + chickenSweetcorn * .50);
                double cheeseTomatoS = (cheeseTomato + cheeseTomato * .50);
                double cheeseHamS = (cheeseHam + cheeseHam * .50);
                double coronationChickenS = (coronationChicken + coronationChicken * .50);
                double englishBreakfastS = (englishBreakfast + englishBreakfast * .50);
                double eggCressS = (eggCress + eggCress * .50);



                //Rounded Selling Price
                double RBLTS = Math.Round(BLTS);
                double RchickenSweetcornS = Math.Round(chickenSweetcornS);
                double RcheeseTomatoS = Math.Round(cheeseTomatoS);
                double RcheeseHamS = Math.Round(cheeseHamS);
                double RcoronationChickenS = Math.Round(coronationChickenS);
                double RenglishBreakfastS = Math.Round(englishBreakfastS);
                double ReggCressS = Math.Round(eggCressS);






                //Profit
                double BLTP = BLTS - BLT;
                double chickenSweetcornP = chickenSweetcornS - chickenSweetcorn;
                double cheeseTomatoP = cheeseTomatoS - cheeseTomato;
                double cheeseHamP = cheeseHamS - cheeseHam;
                double coronationChickenP = coronationChickenS - coronationChicken;
                double englishBreakfastP = englishBreakfastS - englishBreakfast;
                double eggCressP = eggCressS - eggCress;











                var activities = new List<Activity>()
            {
                new Activity(){ date="2021/05/11", numberOfSales=BLT, revenue=RBLTS, profit1=BLTP},
                new Activity(){date="2021/05/12", numberOfSales=chickenSweetcorn, revenue=RchickenSweetcornS, profit1=chickenSweetcornP},
                new Activity(){date="2021/05/13", numberOfSales=cheeseTomato, revenue=cheeseTomatoS, profit1=cheeseTomatoP},
                new Activity(){date="2021/05/14", numberOfSales=cheeseHam, revenue=RcheeseHamS, profit1=cheeseHamP},
                new Activity(){date="2021/05/15", numberOfSales=coronationChicken, revenue=RcoronationChickenS, profit1=coronationChickenP},
                new Activity(){date="2021/05/16", numberOfSales=englishBreakfast, revenue=RenglishBreakfastS, profit1=englishBreakfastP},
                new Activity(){date="2021/05/17", numberOfSales=eggCress, revenue=ReggCressS, profit1=eggCressP},
                new Activity(){date="2021/05/18", numberOfSales=eggCress, revenue=ReggCressS, profit1=eggCressP},
                new Activity(){date="2021/05/19", numberOfSales=eggCress, revenue=ReggCressS, profit1=eggCressP},
                new Activity(){date="2021/05/20", numberOfSales=eggCress, revenue=ReggCressS, profit1=eggCressP},


            };
                CreateSpreadsheet2(activities);
                MessageBox.Show("Spreadsheet has been created");
            }

            void CreateSpreadsheet2(List<Activity> activities)
            {
                string spreadsheetPath = "Task_3.xlsx";
                File.Delete(spreadsheetPath);
                FileInfo spreadsheetInfo = new FileInfo(spreadsheetPath);
                ExcelPackage.LicenseContext = LicenseContext.Commercial;

                ExcelPackage pck = new ExcelPackage(spreadsheetInfo);
                var activitiesWorksheet = pck.Workbook.Worksheets.Add("Activities");
                activitiesWorksheet.Cells["A1"].Value = "Date";
                activitiesWorksheet.Cells["B1"].Value = "Number of Sales";
                activitiesWorksheet.Cells["C1"].Value = "Revenue";
                activitiesWorksheet.Cells["D1"].Value = "Profit";
                activitiesWorksheet.Cells["A1:D1"].Style.Font.Bold = true;

                // Populate spreadsheet with data
                int currentRow = 2;
                foreach (var activity in activities)
                {
                    activitiesWorksheet.Cells["A" + currentRow.ToString()].Value = activity.date;
                    activitiesWorksheet.Cells["B" + currentRow.ToString()].Value = activity.numberOfSales;
                    activitiesWorksheet.Cells["C" + currentRow.ToString()].Value = activity.revenue;
                    activitiesWorksheet.Cells["D" + currentRow.ToString()].Value = activity.profit1;

                    currentRow++;
                }

                activitiesWorksheet.View.FreezePanes(2, 1);
                pck.Save();
            }
        }
    }
    
}
