﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coding_Challenge
{
    public class Activity
    {
        public string Name { get; set; }
        public double totalCost { get; set; }
        public double sellingPrice { get; set; }
        public double profit { get; set; }

        public string date { get; set; }
        public double numberOfSales { get; set; }
        public double revenue { get; set; }
        public double profit1 { get; set; }


    }
}
