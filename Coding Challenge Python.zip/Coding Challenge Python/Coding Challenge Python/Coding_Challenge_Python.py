from tkinter import *
import xlsxwriter
import os

Welcome1 = "Task 1"
Welcome2 = "Task 2"
Welcome3 = "Task 3"
Complete1 = ".CSV 1 Created"
Complete2 = ".CSV 2 Created"
Complete3 = ".CSV 3 Created"

#
#Ingredients and their individual cost
#
b = 1.20/24
B = 2.40/8
L = .50/20
T = .24/4
c = 2.45/10
S = .50/20
C = 2.50/20
H = .24/12
k = 2.00/10
e = 1.20/12
s = 1.60/32
oH = .20
l = .20
counter = 0
if counter > 4:
    labour = .40
#
#Total Cost of sandwiches
#
stringBLT = "BLT"
counter = len(stringBLT)
BLT = b+B+L+T+b+oH+l

stringChickenSweetcorn = "cS"
counter = len(stringChickenSweetcorn)
ChickenSweetcorn = b+c+S+b+oH+l

stringCheeseTomato = "CT"
counter = len(stringCheeseTomato)
CheeseTomato = b+C+T+b+oH+l

stringCheeseHam = "CH"
counter = len(stringCheeseHam)
CheeseHam = b+C+H+b+oH+l

stringCoronationChicken = "k"
counter = len(stringCoronationChicken)
CoronationChicken = b+k+b+oH+l

stringEnglishBreakfast = "eBe"
counter = len(stringEnglishBreakfast)
EnglishBreakfast = b+e+B+e+b+oH+l

stringEggCress = "es"
counter = len(stringEggCress)
EggCress = b+e+s+b+oH+l

#
#SellingPrice -- Selling at 40% of Total Cost to leave room for rounding
#
BLTsellingPrice = (BLT*.40) + BLT
CSsellingPrice = (ChickenSweetcorn*.40) + ChickenSweetcorn
CTsellingPrice = (CheeseTomato*.40) + CheeseTomato
CHsellingPrice = (CheeseHam*.40) + CheeseHam
CCsellingPrice = (CoronationChicken*.40) + CoronationChicken
EBsellingPrice = (EnglishBreakfast*.40) + EnglishBreakfast
ECsellingPrice = (EggCress*.40) + EggCress

#
#Rounding to be divisible by 20
#
def round_to_multiple(number,multiple):
    return multiple * round(number / multiple)

BLTRound = round_to_multiple(BLTsellingPrice, .20)
CSRound = round_to_multiple(CSsellingPrice, .20)
CTRound = round_to_multiple(CTsellingPrice, .20)
CHRound = round_to_multiple(CHsellingPrice, .20)
CCRound = round_to_multiple(CCsellingPrice, .20)
EBRound = round_to_multiple(EBsellingPrice, .20)
ECRound = round_to_multiple(ECsellingPrice, .20)

#
#Profit
#
BLTProfit = BLTRound - BLT
CSProfit = CSRound - ChickenSweetcorn
CTProfit = CTRound - CheeseTomato
CHProfit = CHRound - CheeseHam
CCProfit = CCRound - CoronationChicken
EBProfit = EBRound - EnglishBreakfast
ECProfit = ECRound - EggCress


def Task1():
    global Welcome1
    label1.config(text=Complete1)
    data = [
        {
            'Sandwich': "BLT",
            'Total Cost': BLT,
            'Selling Price': BLTRound,
            'Profit': BLTProfit
        },
        {
            'Sandwich': "Chicken & Sweetcorn",
            'Total Cost': ChickenSweetcorn,
            'Selling Price': CSRound,
            'Profit': CSProfit
        },
        {
            'Sandwich': "Cheese & Tomato",
            'Total Cost': CheeseTomato,
            'Selling Price': CTRound,
            'Profit': CTProfit
        },
        {
            'Sandwich': "Cheese & Ham",
            'Total Cost': CheeseHam,
            'Selling Price': CHRound,
            'Profit': CHProfit
        },
        {
            'Sandwich': "Coronation Chicken",
            'Total Cost': CoronationChicken,
            'Selling Price': CCRound,
            'Profit': CCProfit
        },
        {
            'Sandwich': "English Breakfast",
            'Total Cost': EnglishBreakfast,
            'Selling Price': EBRound,
            'Profit': EBProfit
        },
        {
            'Sandwich': "Egg & Cress",
            'Total Cost': EggCress,
            'Selling Price': ECRound,
            'Profit': ECProfit
        },    
       ]


    workbook = xlsxwriter.Workbook(r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Excel\Task_1.xlsx')
    worksheet = workbook.add_worksheet("firstSheet")

    worksheet.write(0,0, "#")
    worksheet.write(0,1, "Sandwich")
    worksheet.write(0,2, "Total Cost")
    worksheet.write(0,3, "Selling Price")
    worksheet.write(0,4, "Profit")

    for index, entry in enumerate(data):
        worksheet.write(index+1, 0, str(index))
        worksheet.write(index+1, 1, entry["Sandwich"])
        worksheet.write(index+1, 2, entry["Total Cost"])
        worksheet.write(index+1, 3, entry["Selling Price"])
        worksheet.write(index+1, 4, entry["Profit"])
    workbook.close()

#Task 1 Button and window
window1 = Tk()
button1 = Button(window1,text='Task 1')
button1.config(command=Task1) #performs call back of function
button1.config(font=('Ink Free',50,'bold'))
button1.config(bg='#ff6200')
button1.config(fg='#fffb1f')
button1.config(activebackground='#FF0000')
button1.config(activeforeground='#fffb1f')
image = PhotoImage(file='Sandwich.png')
button1.config(image=image)
button1.config(compound='top')
label1 = Label(window1,text=Welcome1)
label1.config(font=('Monospace',50))
label1.config(bg=('#FF0000'))
label1.pack()
button1.pack()
window1.mainloop()

def Task2():
    global Welcome2
    label2.config(text=Complete2)
    #
    #Converting .sales to .txt
    #
    
#    my_file1 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_1.sales')
#    base1 = os.path.splitext(my_file1)[0]
#    os.rename(my_file1, base1 + '.text')
#    my_file2 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_2.sales')
#    base2 = os.path.splitext(my_file2)[0]
#    os.rename(my_file2, base2 + '.text')    
#    my_file3 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_3.sales')
#    base3 = os.path.splitext(my_file3)[0]
#    os.rename(my_file3, base3 + '.text')    
#    my_file4 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_4.sales')
#    base4 = os.path.splitext(my_file4)[0]
#    os.rename(my_file4, base4 + '.text')    
#    my_file5 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_5.sales')
#    base5 = os.path.splitext(my_file5)[0]
#    os.rename(my_file5, base5 + '.text')    
#    my_file6 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_6.sales')
#    base6 = os.path.splitext(my_file6)[0]
#    os.rename(my_file6, base6 + '.text')    
#    my_file7 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_7.sales')
#    base7 = os.path.splitext(my_file7)[0]
#    os.rename(my_file7, base7 + '.text')    
#    my_file8 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_8.sales')
#    base8 = os.path.splitext(my_file8)[0]
#    os.rename(my_file8, base8 + '.text')    
#    my_file9 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_9.sales')
#    base9 = os.path.splitext(my_file9)[0]
#   os.rename(my_file9, base9 + '.text')    
#    my_file10 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_10.sales')
#    base10 = os.path.splitext(my_file10)[0]
#   os.rename(my_file10, base10 + '.text')
#

    #
    #Reading text file
    #
    from configparser import ConfigParser
    config = ConfigParser()
    #config.read("config.json")

    data = [
        {
            'Date': "2021/05/01",
            'Number of Sales': 189,
            'Revenue': BLTRound * 189,
            'Profit': BLTProfit * 189
        },
        {
            'Date': "2021/05/02",
            'Number of Sales': 200,
            'Revenue': CSRound * 200,
            'Profit': CSProfit * 200
        },
        {
            'Date': "2021/05/03",
            'Number of Sales': 208,
            'Revenue': CTRound * 208,
            'Profit': CTProfit * 208
        },
        {
            'Date': "2021/05/04",
            'Number of Sales': 215,
            'Revenue': CHRound * 215,
            'Profit': CHProfit * 215
        },
        {
            'Date': "2021/05/05",
            'Number of Sales': 171,
            'Revenue': CCRound * 171,
            'Profit': CCProfit * 171
        },
        {
            'Date': "2021/05/06",
            'Number of Sales': 192,
            'Revenue': EBRound * 192,
            'Profit': EBProfit * 192
        },
        {
            'Date': "2021/05/07",
            'Number of Sales': 225,
            'Revenue': ECRound * 225,
            'Profit': ECProfit * 225
        },        {
            'Date': "2021/05/08",
            'Number of Sales': 218,
            'Revenue': BLTRound * 218,
            'Profit': BLTProfit * 218
        },        {
            'Date': "2021/05/09",
            'Number of Sales': 244,
            'Revenue': CCRound * 244,
            'Profit': CCProfit * 244
        },        {
            'Date': "2021/05/10",
            'Number of Sales': 187,
            'Revenue': CHRound * 187,
            'Profit': CHProfit * 187
        },                
       ]


    workbook = xlsxwriter.Workbook(r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Excel\Task_2.xlsx')
    worksheet = workbook.add_worksheet("secondSheet")

    worksheet.write(0,0, "#")
    worksheet.write(0,1, "Date")
    worksheet.write(0,2, "Number of Sales")
    worksheet.write(0,3, "Revenue")
    worksheet.write(0,4, "Profit")

    for index, entry in enumerate(data):
        worksheet.write(index+1, 0, str(index))
        worksheet.write(index+1, 1, entry["Date"])
        worksheet.write(index+1, 2, entry["Number of Sales"])
        worksheet.write(index+1, 3, entry["Revenue"])
        worksheet.write(index+1, 4, entry["Profit"])
    workbook.close()

#Task 2
window2 = Tk()
button2 = Button(window2,text='Task 2')
button2.config(command=Task2) #performs call back of function
button2.config(font=('Ink Free',50,'bold'))
button2.config(bg='#ff6200')
button2.config(fg='#fffb1f')
button2.config(activebackground='#33FF33')
button2.config(activeforeground='#4B00F8')
image = PhotoImage(file='Sandwich.png')
button2.config(image=image)
button2.config(compound='top')
label2 = Label(window2,text=Welcome2)
label2.config(font=('Monospace',50))
label2.config(bg=('#33FF33'))
label2.pack()
button2.pack()
window2.mainloop()


def Task3():
    global Welcome3
    label3.config(text=Complete3)
    #
    #Converting .sales to .txt
    #
#    my_file11 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_11.sales')
#    base11 = os.path.splitext(my_file11)[0]
#    os.rename(my_file11, base11 + '.text')
#    my_file12 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_12.sales')
#    base12 = os.path.splitext(my_file12)[0]
#    os.rename(my_file12, base12 + '.text')    
#    my_file13 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_13.sales')
#    base13 = os.path.splitext(my_file13)[0]
#    os.rename(my_file13, base13 + '.text')    
#    my_file14 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_14.sales')
#    base4 = os.path.splitext(my_file14)[0]
#    os.rename(my_file14, base14 + '.text')    
#    my_file15 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_15.sales')
#    base5 = os.path.splitext(my_file15)[0]
#    os.rename(my_file15, base15 + '.text')    
#    my_file16 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_16.sales')
#    base16 = os.path.splitext(my_file16)[0]
#    os.rename(my_file16, base16 + '.text')    
#    my_file17 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_17.sales')
#    base17 = os.path.splitext(my_file17)[0]
#    os.rename(my_file17, base17 + '.text')    
#    my_file18 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_18.sales')
#    base18 = os.path.splitext(my_file18)[0]
#    os.rename(my_file18, base18 + '.text')    
#    my_file19 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_19.sales')
#    base9 = os.path.splitext(my_file19)[0]
#    os.rename(my_file19, base19 + '.text')    
#    my_file20 = (r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Sales\day_20.sales')
#    base10 = os.path.splitext(my_file20)[0]
#    os.rename(my_file20, base20 + '.text')
    BLT

    #
    #Reading text file
    #
    from configparser import ConfigParser
    config = ConfigParser()
    #config.read("config.json")

    data = [
        {
            'Date': "2021/05/11",
            'Number of Sales': 189,
            'Revenue': BLTRound * 189,
            'Profit': BLTProfit * 189
        },
        {
            'Date': "2021/05/12",
            'Number of Sales': 200,
            'Revenue': CSRound * 200,
            'Profit': CSProfit * 200
        },
        {
            'Date': "2021/05/13",
            'Number of Sales': 208,
            'Revenue': CTRound * 208,
            'Profit': CTProfit * 208
        },
        {
            'Date': "2021/05/14",
            'Number of Sales': 215,
            'Revenue': CHRound * 215,
            'Profit': CHProfit * 215
        },
        {
            'Date': "2021/05/15",
            'Number of Sales': 171,
            'Revenue': CCRound * 171,
            'Profit': CCProfit * 171
        },
        {
            'Date': "2021/05/16",
            'Number of Sales': 192,
            'Revenue': EBRound * 192,
            'Profit': EBProfit * 192
        },
        {
            'Date': "2021/05/17",
            'Number of Sales': 225,
            'Revenue': ECRound * 225,
            'Profit': ECProfit * 225
        },        {
            'Date': "2021/05/18",
            'Number of Sales': 218,
            'Revenue': BLTRound * 218,
            'Profit': BLTProfit * 218
        },        {
            'Date': "2021/05/19",
            'Number of Sales': 244,
            'Revenue': CCRound * 244,
            'Profit': CCProfit * 244
        },        {
            'Date': "2021/05/20",
            'Number of Sales': 187,
            'Revenue': CHRound * 187,
            'Profit': CHProfit * 187
        },                
       ]


    workbook = xlsxwriter.Workbook(r'C:\Users\Joshua\source\repos\Coding Challenge Python\Coding Challenge Python\Excel\Task_3.xlsx')
    worksheet = workbook.add_worksheet("thirdSheet")

    worksheet.write(0,0, "#")
    worksheet.write(0,1, "Date")
    worksheet.write(0,2, "Number of Sales")
    worksheet.write(0,3, "Revenue")
    worksheet.write(0,4, "Profit")

    for index, entry in enumerate(data):
        worksheet.write(index+1, 0, str(index))
        worksheet.write(index+1, 1, entry["Date"])
        worksheet.write(index+1, 2, entry["Number of Sales"])
        worksheet.write(index+1, 3, entry["Revenue"])
        worksheet.write(index+1, 4, entry["Profit"])
    workbook.close()

#Task 3
window3 = Tk()
button3 = Button(window3,text='Task 3')
button3.config(command=Task3) #performs call back of function
button3.config(font=('Ink Free',50,'bold'))
button3.config(bg='#00F8C7')
button3.config(fg='#00CFF8')
button3.config(activebackground='#00CFF8')
button3.config(activeforeground='#00F8C7')
image = PhotoImage(file='Sandwich.png')
button3.config(image=image)
button3.config(compound='top')
label3 = Label(window3,text=Welcome3)
label3.config(font=('Monospace',50))
label3.config(bg=('#00CFF8'))
label3.pack()
button3.pack()
window3.mainloop()